<?php

include_once('./config/database.php');
include_once('./objects/Joke.php');
include_once('./create_new_table.php');

$database = new Database();
$db = $database->connect();
$joke = new Joke($db);
create_table($db);
$request_method = $_SERVER["REQUEST_METHOD"];

switch ($request_method) {
    case 'GET':
        if (!empty($_GET["id"]))
        {
            $id = intval($_GET["id"]);
            $joke->get_joke($id);
        } else
            $joke->get_jokes();
        break;

    case 'POST':
        $joke->insert_joke();
        break;

    case 'PUT':
        $id = intval($_GET["id"]);
        $author = strval($_GET["author"]);
        $joke->update_joke($id, $author);
        break;

    case 'DELETE':
        $id = intval($_GET["id"]);
        $author = strval($_GET["author"]);
        $joke->delete_joke($id, $author);
        break;

    default:
        header("HTTP/1.0 405 Method Not Allowed");
}

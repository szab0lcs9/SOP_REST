<?php

Class User {
    private $username;
    private $password;
}